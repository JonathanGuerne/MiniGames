package packets.BattleShip;

import packets.Packet;

/**
 * Created by anthony.gillioz on 11.07.2017.
 */

public class BattleShipEndGamePacket extends Packet
{
    public int idWinner;
}
