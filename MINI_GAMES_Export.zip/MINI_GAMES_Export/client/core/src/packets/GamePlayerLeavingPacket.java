package packets;

/**
 * Created by jonathan.guerne on 10.07.2017.
 */

public class GamePlayerLeavingPacket extends Packet {
    public int playerid;
    public String playerName;
}
