package packets.morpion;

import packets.Packet;

/**
 * Created by jonathan.guerne on 31.05.2017.
 */

public class MorpionStartPacket extends Packet {
    public int idPlayer;
}
