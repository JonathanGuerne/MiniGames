package packets.morpion;

import packets.Packet;

/**
 * Created by jonathan.guerne on 02.07.2017.
 */

public class MorpionEndGamePacket extends Packet {
    public char[] tabGame;
    public int gameId;
    public int winnerId;
}
