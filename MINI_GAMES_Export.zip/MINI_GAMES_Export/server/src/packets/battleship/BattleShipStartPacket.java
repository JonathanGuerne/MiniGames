package packets.battleship;

import packets.Packet;

/**
 * Created by anthony.gillioz on 03.07.2017.
 */

public class BattleShipStartPacket extends Packet {
    public int idPlayer;
}
