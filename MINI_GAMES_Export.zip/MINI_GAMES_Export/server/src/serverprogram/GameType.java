package serverprogram;

/* ---------------------------------------------------------------------------------------------
 * Projet        : HES d'été - Minis Games
 * Auteurs       : Marc Friedli, Anthony gilloz, Jonathan guerne
 * Date          : Juillet 2017
 * ---------------------------------------------------------------------------------------------
 * GameType.java   : Enum use to list all type of game
 * ---------------------------------------------------------------------------------------------
 */

public enum GameType {
    MORPION,BATTLESHIP;
}
