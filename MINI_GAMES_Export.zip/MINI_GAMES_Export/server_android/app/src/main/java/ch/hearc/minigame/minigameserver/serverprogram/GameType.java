package ch.hearc.minigame.minigameserver.serverprogram;

/**
 * Created by jonathan.guerne on 21.06.2017.
 */

public enum GameType {
    MORPION,BATTLESHIP;
}
