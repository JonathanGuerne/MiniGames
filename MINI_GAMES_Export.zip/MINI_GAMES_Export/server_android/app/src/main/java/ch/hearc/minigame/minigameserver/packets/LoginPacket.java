package ch.hearc.minigame.minigameserver.packets;

/**
 * Created by jonathan.guerne on 01.05.2017.
 */

public class LoginPacket extends Packet {
    public String loginMessage;
}

