package ch.hearc.minigame.minigameserver.packets.battleship;

import ch.hearc.minigame.minigameserver.packets.Packet;

/**
 * Created by anthony.gillioz on 03.07.2017.
 */

public class BattleShipStartPacket extends Packet {
    public int idPlayer;
}
